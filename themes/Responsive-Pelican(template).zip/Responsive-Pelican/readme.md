Pelican theme - Responsive Pelican
================================

Responsive Pelican
----------

Responsive Pelican is a [pelican](https://github.com/getpelican/pelican) theme which modified from wordpress theme [Responsive](http://wordpress.org/themes/responsive)



Screenshot
----------

  ![Screenshot](screenshot.PNG)
